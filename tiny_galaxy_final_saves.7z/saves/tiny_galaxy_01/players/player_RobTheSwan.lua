local settings =
{
	homeLocation = 
	{
		roomFolder = "default/",
		chunkId = 
		{
			0,
			1,
			2,
		},
		xyz = 
		{
			31.5818,
			10.2502,
			30.7539,
		},
		ypr = 
		{
			0.0,
			6.282,
			0,
		},
	},
	permissionLevel = "admin",
	xyz = 
	{
		ypr = 
		{
			0.0,
			6.282,
			0,
		},
		xyz = 
		{
			31.5818,
			10.2502,
			30.7539,
		},
		chunkId = 
		{
			0,
			1,
			2,
		},
		roomFolder = "default/",
	},
	accountPassword = "meowmeow",
	gravityDir = "DOWN",
}

return settings
