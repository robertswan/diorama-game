local settings =
{
	homeLocation = 
	{
		roomFolder = "default/",
		chunkId = 
		{
			1,
			1,
			2,
		},
		xyz = 
		{
			5.05946,
			14.2503,
			31.7124,
		},
		ypr = 
		{
			0.694,
			0,
			0,
		},
	},
	permissionLevel = "mod",
	xyz = 
	{
		ypr = 
		{
			1.0028,
			-0.00600009,
			0,
		},
		xyz = 
		{
			0.0,
			0.0,
			0.0,
		},
		chunkId = 
		{
			1,
			1,
			2,
		},
		roomFolder = "default/",
	},
	accountPassword = "meowmeow",
	gravityDir = "DOWN",
}

return settings
