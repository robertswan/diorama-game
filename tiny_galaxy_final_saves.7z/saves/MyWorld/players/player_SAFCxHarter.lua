local settings =
{
	homeLocation = 
	{
		roomFolder = "default/",
		chunkId = 
		{
			-1,
			0,
			2,
		},
		xyz = 
		{
			27.0217,
			0.250231,
			11.2121,
		},
		ypr = 
		{
			0.738784,
			-100.11,
			0,
		},
	},
	permissionLevel = "mod",
	xyz = 
	{
		ypr = 
		{
			0.212,
			-10.982,
			0,
		},
		xyz = 
		{
			27.8374,
			1.25017,
			9.14238,
		},
		chunkId = 
		{
			2,
			-1,
			-1,
		},
		roomFolder = "default/",
	},
	accountPassword = "password",
	gravityDir = "DOWN",
}

return settings
