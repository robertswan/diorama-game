local settings =
{
	xyz = 
	{
		xyz = 
		{
			16.8974,
			0.250155,
			29.8019,
		},
		roomFolder = "default/",
		ypr = 
		{
			-0.441203,
			5.59555,
			0,
		},
		chunkId = 
		{
			0,
			-1,
			2,
		},
	},
	permissionLevel = "builder",
	accountPassword = "LetsRaceBwoi",
	gravityDir = "DOWN",
}

return settings
