local settings =
{
	xyz = 
	{
		xyz = 
		{
			16.765,
			0.250002,
			30.8452,
		},
		roomFolder = "default/",
		ypr = 
		{
			-0.471205,
			4.11119,
			0,
		},
		chunkId = 
		{
			0,
			-1,
			1,
		},
	},
	permissionLevel = "builder",
	accountPassword = "12345",
	gravityDir = "DOWN",
}

return settings
