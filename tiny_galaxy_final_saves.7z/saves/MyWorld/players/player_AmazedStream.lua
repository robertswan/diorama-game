local settings =
{
	xyz = 
	{
		roomFolder = "default/",
		xyz = 
		{
			27.2982,
			0.250166,
			3.93335,
		},
		chunkId = 
		{
			0,
			0,
			-1,
		},
		ypr = 
		{
			0.406794,
			8.51602,
			0,
		},
	},
	accountPassword = "robthepassword",
	gravityDir = "DOWN",
	permissionLevel = "builder",
}

return settings
