local settings =
{
	xyz = 
	{
		xyz = 
		{
			9.62095,
			31.75,
			28.2188,
		},
		roomFolder = "default/",
		ypr = 
		{
			-0.534796,
			5.34257,
			0,
		},
		chunkId = 
		{
			1,
			1,
			0,
		},
	},
	permissionLevel = "builder",
	accountPassword = "password",
	gravityDir = "UP",
}

return settings
