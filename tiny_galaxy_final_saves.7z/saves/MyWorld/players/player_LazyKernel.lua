local settings =
{
	xyz = 
	{
		xyz = 
		{
			27.5094,
			5.25001,
			13.6455,
		},
		roomFolder = "default/",
		ypr = 
		{
			0.0527973,
			2.30548,
			0,
		},
		chunkId = 
		{
			-1,
			0,
			2,
		},
	},
	permissionLevel = "builder",
	accountPassword = "Underppl911",
	gravityDir = "DOWN",
}

return settings
