local settings =
{
	permissionLevel = "mod",
	gravityDir = "DOWN",
	accountPassword = "meowmeow",
	homeLocation = 
	{
		xyz = 
		{
			6.2392,
			14.2501,
			30.7613,
		},
		ypr = 
		{
			0.883204,
			0.0,
			0,
		},
		chunkId = 
		{
			1,
			1,
			2,
		},
		roomFolder = "default/",
	},
	xyz = 
	{
		roomFolder = "default/",
		ypr = 
		{
			0.883204,
			0.0,
			0,
		},
		chunkId = 
		{
			1,
			1,
			2,
		},
		xyz = 
		{
			6.2392,
			14.2501,
			30.7613,
		},
	},
}

return settings
