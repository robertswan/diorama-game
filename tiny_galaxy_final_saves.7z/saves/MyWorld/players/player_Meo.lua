local settings =
{
	xyz = 
	{
		xyz = 
		{
			27.3727,
			3.25008,
			17.3099,
		},
		ypr = 
		{
			0.216796,
			-527.499,
			0,
		},
		roomFolder = "default/",
		chunkId = 
		{
			-3,
			0,
			2,
		},
	},
	permissionLevel = "builder",
	accountPassword = "gurgel76",
	gravityDir = "DOWN",
}

return settings
