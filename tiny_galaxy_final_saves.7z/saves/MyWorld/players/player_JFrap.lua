local settings =
{
	gravityDir = "DOWN",
	accountPassword = "password",
	xyz = 
	{
		roomFolder = "default/",
		xyz = 
		{
			12.5424,
			0.250027,
			0.495031,
		},
		chunkId = 
		{
			-1,
			0,
			1,
		},
		ypr = 
		{
			0.480808,
			10.95,
			0,
		},
	},
	permissionLevel = "mod",
}

return settings
