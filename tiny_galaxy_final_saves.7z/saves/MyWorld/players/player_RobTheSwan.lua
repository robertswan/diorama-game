local settings =
{
	accountPassword = "meowmeow",
	xyz = 
	{
		chunkId = 
		{
			-1,
			-1,
			2,
		},
		roomFolder = "default/",
		xyz = 
		{
			31.9979,
			0.250139,
			15.2181,
		},
		ypr = 
		{
			0.252796,
			1.81963,
			0,
		},
	},
	homeLocation = 
	{
		xyz = 
		{
			8.60143,
			6.25018,
			30.9481,
		},
		chunkId = 
		{
			2,
			0,
			-1,
		},
		ypr = 
		{
			1.5708,
			0.223194,
			0,
		},
		roomFolder = "default/",
	},
	gravityDir = "DOWN",
	permissionLevel = "admin",
}

return settings
