local settings =
{
	xyz = 
	{
		xyz = 
		{
			7.71094,
			6.2501,
			19.8952,
		},
		ypr = 
		{
			0.284796,
			-155.436,
			0,
		},
		roomFolder = "default/",
		chunkId = 
		{
			3,
			0,
			3,
		},
	},
	permissionLevel = "builder",
	accountPassword = "cloudgatherer",
	gravityDir = "DOWN",
}

return settings
