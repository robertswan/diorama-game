local settings =
{
	xyz = 
	{
		xyz = 
		{
			6.29466,
			4.2501,
			7.68111,
		},
		roomFolder = "default/",
		ypr = 
		{
			1.006,
			3.082,
			0,
		},
		chunkId = 
		{
			0,
			0,
			0,
		},
	},
	permissionLevel = "builder",
	accountPassword = "123456",
	gravityDir = "DOWN",
}

return settings
