local settings =
{
	xyz = 
	{
		xyz = 
		{
			4.77467,
			0.250072,
			31.5917,
		},
		roomFolder = "default/",
		ypr = 
		{
			-0.133204,
			4.47191,
			0,
		},
		chunkId = 
		{
			-1,
			-1,
			2,
		},
	},
	permissionLevel = "mod",
	accountPassword = "sebi13",
	gravityDir = "DOWN",
}

return settings
