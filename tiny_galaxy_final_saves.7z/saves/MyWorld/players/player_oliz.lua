local settings =
{
	xyz = 
	{
		roomFolder = "default/",
		chunkId = 
		{
			0,
			-1,
			0,
		},
		ypr = 
		{
			-0.141206,
			-16.346,
			0,
		},
		xyz = 
		{
			11.9081,
			1.25002,
			23.6906,
		},
	},
	homeLocation = 
	{
		roomFolder = "default/",
		xyz = 
		{
			19.2633,
			13.25,
			12.2146,
		},
		ypr = 
		{
			1.3148,
			-24.52,
			0,
		},
		chunkId = 
		{
			1,
			0,
			0,
		},
	},
	accountPassword = "cloudgatherer",
	permissionLevel = "builder",
	gravityDir = "DOWN",
}

return settings
