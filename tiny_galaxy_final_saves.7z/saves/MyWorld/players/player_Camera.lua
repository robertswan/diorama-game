local settings =
{
	accountPassword = "meowmeow",
	xyz = 
	{
		chunkId = 
		{
			0,
			0,
			2,
		},
		roomFolder = "default/",
		xyz = 
		{
			12.2942,
			7.25027,
			25.6637,
		},
		ypr = 
		{
			0.0392041,
			5.22718,
			0,
		},
	},
	homeLocation = 
	{
		ypr = 
		{
			0.883204,
			0,
			0,
		},
		roomFolder = "default/",
		xyz = 
		{
			6.2392,
			14.2501,
			30.7613,
		},
		chunkId = 
		{
			1,
			1,
			2,
		},
	},
	gravityDir = "DOWN",
	permissionLevel = "mod",
}

return settings
