local settings =
{
	gravityDir = "DOWN",
	accountPassword = "password",
	xyz = 
	{
		chunkId = 
		{
			-1,
			-1,
			-1,
		},
		roomFolder = "default/",
		xyz = 
		{
			17.9462,
			30.2503,
			29.3589,
		},
		ypr = 
		{
			0.0887964,
			-5.376,
			0,
		},
	},
	permissionLevel = "builder",
}

return settings
