local settings =
{
	gravityDir = "DOWN",
	homeLocation = 
	{
		ypr = 
		{
			0.544796,
			-48.6301,
			0,
		},
		roomFolder = "default/",
		xyz = 
		{
			6.70071,
			0.250137,
			19.803,
		},
		chunkId = 
		{
			1,
			0,
			-1,
		},
	},
	permissionLevel = "builder",
	xyz = 
	{
		ypr = 
		{
			0.740797,
			-56.8001,
			0,
		},
		roomFolder = "default/",
		xyz = 
		{
			17.0076,
			13.25,
			10.1309,
		},
		chunkId = 
		{
			1,
			0,
			0,
		},
	},
	accountPassword = "1234",
}

return settings
