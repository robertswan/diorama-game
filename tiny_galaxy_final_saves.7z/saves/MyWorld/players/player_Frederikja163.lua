local settings =
{
	gravityDir = "DOWN",
	accountPassword = "mbk82zrc",
	xyz = 
	{
		roomFolder = "default/",
		xyz = 
		{
			28.4925,
			0.250049,
			31.7468,
		},
		chunkId = 
		{
			0,
			0,
			2,
		},
		ypr = 
		{
			1.14279,
			9.33401,
			0,
		},
	},
	permissionLevel = "builder",
}

return settings
