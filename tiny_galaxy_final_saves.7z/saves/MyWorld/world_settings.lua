-- auto generated file. safe to hand edit
local worldSettings =
{
    gameMode = "tiny_galaxy_creative/",
    shouldSave = true,
}

return worldSettings
