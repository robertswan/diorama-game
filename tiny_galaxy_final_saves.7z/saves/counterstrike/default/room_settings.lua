-- repeatedly generated file. not safe to hand edit
local roomSettings =
{
	generators = 
	{
		
		{
			voxelPass = 
			{
			},
			weightPass = 
			{
				
				{
					baseVoxel = -16,
					heightInVoxels = 32,
					mode = "replace",
					type = "gradient",
				},
				
				{
					mode = "lessThan",
					octaves = 5,
					perOctaveAmplitude = 0.5,
					perOctaveFrequency = 2,
					scale = 128,
					type = "perlinNoise",
				},
			},
		},
	},
    roomShape = 
    {
        x = 
        {
            max = 3,
            min = -4,
        },
        y = 
        {
            max = 1,
            min = -1,
        },
        z = 
        {
            max = 3,
            min = -4,
        },
    },	
	path = "default",
	randomSeedAsString = "Blackbod",
	terrainId = "paramaterized",
}

return roomSettings
