-- auto generated file. safe to hand edit
local worldSettings =
{
	gameMode = "creative/",
	shouldSave = true,
}

return worldSettings
