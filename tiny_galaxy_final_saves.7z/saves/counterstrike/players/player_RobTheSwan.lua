local settings =
{
	permissionLevel = "admin",
	xyz = 
	{
		chunkId = 
		{
			2,
			0,
			-4,
		},
		xyz = 
		{
			14.6294,
			16.2502,
			4.74871,
		},
		ypr = 
		{
			0.350796,
			2.67603,
			0,
		},
		roomFolder = "default/",
	},
	gravityDir = "DOWN",
	accountPassword = "meowmeow",
}

return settings
