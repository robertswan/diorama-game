local settings =
{
	permissionLevel = "mod",
	xyz = 
	{
		chunkId = 
		{
			3,
			0,
			-4,
		},
		xyz = 
		{
			25.2229,
			14.25,
			5.14846,
		},
		ypr = 
		{
			0.412795,
			-179.184,
			0,
		},
		roomFolder = "default/",
	},
	gravityDir = "DOWN",
	accountPassword = "password",
}

return settings
